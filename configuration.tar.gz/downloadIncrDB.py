#!/usr/bin/env python
import requests 
import xml.etree.ElementTree as ET
import re
import tarfile
from clint.textui import progress
import os, sys
import shutil
import time
import datetime
from concurrent.futures import ThreadPoolExecutor
from threading import Thread, Lock

PERSISTENCE_SNAPSHOT_URL='http://zilliqa-incremental.s3.amazonaws.com'
STATEDELTA_DIFF_URL='http://zilliqa-statedelta.s3.amazonaws.com'
CHUNK_SIZE = 4096
EXPEC_LEN = 2
TESTNET_NAME= 'mainnet-changi'
MAX_WORKER_JOBS = 50

Exclude_txnBodies = True

mutex = Lock()

def UploadLock():
	response = requests.get(PERSISTENCE_SNAPSHOT_URL+"/"+TESTNET_NAME+"/.lock")
	if response.status_code == 200:
		return True
	return False

def GetEntirePersistenceFromS3():
	CleanupDir('persistence')
	if GetAllObjectsFromS3(PERSISTENCE_SNAPSHOT_URL) == 1 :
		exit(1)

def GetStateDeltaFromS3():
	CleanupCreateAndChangeDir('StateDeltaFromS3')
	GetAllObjectsFromS3(STATEDELTA_DIFF_URL)
	ExtractAllGzippedObjects()

def GetAllObjectsFromS3(url):
	MARKER = ''
	list_of_keyurls = []
	# Try get the entire persistence keys.
	# S3 limitation to get only max 1000 keys. so work around using marker.
	while True:
		response = requests.get(url, params={"prefix":TESTNET_NAME, "max-keys":1000, "marker": MARKER})
		tree = ET.fromstring(response.text)
		startInd = 5
		if(tree[startInd:] == []):
			print("Empty response")
			return 1
		for key in tree[startInd:]:
			key_url = key[0].text
			if (not (Exclude_txnBodies and "txBodies" in key_url) and not ("microBlocks" in key_url)):
				list_of_keyurls.append(url+"/"+key_url)
				print(key_url)
		
		istruncated=tree[4].text
		if istruncated == 'true':
			nextkey=list_of_keyurls[-1] 
			MARKER=nextkey
			print(istruncated)
		else:
			break

	with ThreadPoolExecutor(max_workers=MAX_WORKER_JOBS) as pool:
		pool.map(GetPersistenceKey,list_of_keyurls)

	return 0

def GetPersistenceKey(key_url):
	response = requests.get(key_url, stream=True)
	filename = key_url.replace(key_url[:key_url.index(TESTNET_NAME+"/")+len(TESTNET_NAME+"/")],"").strip()

	dirname = os.path.dirname(filename).strip()
	if dirname != "":
		mutex.acquire()
		if not os.path.exists(dirname):
			os.makedirs(dirname)
		mutex.release()

	with open(filename,'wb') as f:
		total_length = response.headers.get('content-length')
		total_length = int(total_length)
		for chunk in progress.bar(response.iter_content(chunk_size=CHUNK_SIZE), expected_size=(total_length/CHUNK_SIZE) + 1):
			if chunk:
				f.write(chunk)
				f.flush()

def CleanupDir(folderName):
	if os.path.exists("./"+folderName):
		shutil.rmtree(folderName)
	
def CleanupCreateAndChangeDir(folderName):
	CleanupDir(folderName)
	os.mkdir(folderName)
	os.chdir(folderName)

def ExtractAllGzippedObjects():
	files = [f for f in os.listdir('.') if os.path.isfile(f)]
	for f in files:
		if f.endswith('.tar.gz'):
			tf = tarfile.open(f)
			tf.extractall()
			os.remove(f)
		else:
			if os.path.isfile(f):
				os.remove(f)
			else:
				shutil.rmtree(f)

def run():
	while (True):
		try:
			if(UploadLock() == False):
				print("[" + str(datetime.datetime.now()) + "] Started downloading entire persistence")
				GetEntirePersistenceFromS3()
			else:
				continue

			if(UploadLock() == True):
				print("Upload has been triggered. Downloading StateDelta now can cause inconsistent data. will restart again..")
				continue

			print("Started downloading State-Delta")
			GetStateDeltaFromS3()
			break

		except Exception as e:
			print(e)
			print("Error downloading!! Will try again")
			time.sleep(5)
			continue

	print("[" + str(datetime.datetime.now()) + "] Done!")
	exit(0)

if __name__ == "__main__":
	run()
